#include <iostream>

using namespace std;

int main(int argc, char** argv) {
	// I think we need some extra info here
	cout << "Hello, Hydrargyrum!" << endl;
	cout << "We edit this file now..." << endl;
	return 0;
}
